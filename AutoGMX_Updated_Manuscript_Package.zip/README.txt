AutoGMX Updated Manuscript Package

This package incorporates the executed AutoGMX output archive supplied by the user.

Main manuscript:
- AutoGMX_Updated_Manuscript.docx

Figures:
- Original architecture/workflow schematics from the previous manuscript package
- Figure 6: structural results montage from actual output
- Figure 7: thermodynamic results montage from actual output
- Figure 8: PCA/free-energy results montage from actual output
- Figure 9: MM-PBSA diagnostic output
- Figure 10: observed execution trace

Selected output data:
- analysis plots and numerical XVG/CSV/JSON summaries
- MDP files
- final PDB
- stage logs
- original generated PDF report

Important scientific caveats:
1. The production simulation is 1 ns with 101 analyzed frames.
2. job.json requests charmm36-feb2026_cgenff-5.0, but the generated protein topology records amber99sb-ildn. This discrepancy must be resolved/documented.
3. MM-PBSA did not produce valid binding energies: grompp failed for all 11 sampled frames and PDB2PQR returned a permission error. The reported +2549.79 kcal/mol value is not interpreted as a binding free energy.
4. Protein-ligand hydrogen-bond analysis was skipped after failure.
